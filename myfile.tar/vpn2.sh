#!/bin/bash

# This script assists with upgrade from VPN v1 to v2 security model (CDS 6.1.1)

# Set colours and text mode variables
red=$(tput setaf 1)
green=$(tput setaf 2)
yellow=$(tput setaf 3)
blue=$(tput setaf 4)
magenta=$(tput setaf 5)
cyan=$(tput setaf 6)
white=$(tput setaf 7)
bold=$(tput bold)
ulon=$(tput smul)
uloff=$(tput rmul)
reset=$(tput sgr0)

#Procs:
pause(){
        read -n1 -rsp $'Once completed press any key to continue or Ctrl+C to exit...\n'
}

#main

echo "${green}${bold}Gathering VPN CN....."

VPN_IP=$(ifconfig tun0 | egrep -o 'addr:([[:digit:]]{1,3}\.){3}[[:digit:]]{1,3}' | egrep -o '[[:digit:]].*')
CN=$(grep -o "ActVpn...." /act/etc/openvpn.d/client.crt)

if [[  "${CN}" == "" ]]
then
        echo "${red}Could not find VPN CN of format ActVpn<bbsid>"
        echo "${red}Please manually find bbsid and generate new certs of format ActVpn<bbsid> at"
        echo "${red}https://avin.actifio.com/actifio/custvpn.html and manually upload to /dumps on cluster"
        echo "${red}Once uploaded please re-run this script, exiting....."
        exit
fi



echo -n "${green}${bold}"
echo "Found CN $CN continuing...."
echo "Please visit ${blue}${ulon}https://avin.actifio.com/actifio/custvpn.html${uloff}${green}${bold} and enter CN to receive certs"
echo "Once downloaded to local machine please upload to cluster using the following syntax:"
echo -n "${reset}"
echo "${cyan}scp ${CN}.tgz root@${VPN_IP}:/dumps"

echo "${green}${bold}"
pause

#Start VPN Upgrade
echo "Output from /act/etc/sitevpn.conf:"
echo "${reset}"
cat /act/etc/sitevpn.conf

echo "${green}${bold}"
echo "Checking for existance of uploaded VPN cert ${CN}.tgz in /dumps"
if [ ! -f "/dumps/${CN}.tgz" ]
then
    echo "${red}File ${CN}.tgz does not exist, exiting....."
    exit
fi

echo -n "${green}${bold}"
echo "Found ${CN}.tgz, continuing....."
echo "Backing up original files....."
echo "/act/etc/sitevpn.conf -> /act/etc/sitevpn.conf-vpn1.$(date +%m%d%YT%H:%M:%S)"
echo -n "${reset}"
cp -rp /act/etc/sitevpn.conf /act/etc/sitevpn.conf-vpn1.$(date +%m%d%YT%H:%M:%S)
echo -n "${green}${bold}"
echo "Done."
echo "/act/etc/openvpn.d -> /act/etc/openvpn.d-vpn1.$(date +%m%d%YT%H:%M:%S)"
echo -n "${reset}"
cp -rp /act/etc/openvpn.d /act/etc/openvpn.d-vpn1.$(date +%m%d%YT%H:%M:%S)
echo -n "${green}${bold}"
echo "Done."
echo "Listing contents of /act/etc/openvpn.d pre extraction"
echo -n "${reset}"
ls -l /act/etc/openvpn.d
rm /act/etc/openvpn.d/client.crt
rm /act/etc/openvpn.d/client.key

echo "${green}${bold}Linking Certs${reset}"
ln -s /act/etc/openvpn.d/${CN}.crt /act/etc/openvpn.d/client.crt
ln -s /act/etc/openvpn.d/${CN}.key /act/etc/openvpn.d/client.key

echo "${green}${bold}Starting extraction of ${CN}.tgz into /act/etc/openvpn.d ${reset}"
tar zxvf /dumps/${CN}.tgz -C /act/etc/openvpn.d

echo "${green}${bold}Listing contents of /act/etc/openvpn.d post extraction ${reset}"
ls -l /act/etc/openvpn.d

echo "${green}${bold}Disabling SecureConnect..... ${reset}"
udstask setremotesupport -secureconnect off
sleep 5

echo "${green}${bold}Removing /act/etc/sitevpn.conf ${reset}"
rm /act/etc/sitevpn.conf

echo "${green}${bold}Setting VPN v2 parameters..... ${reset}"
udstask setparameter -param secureconnect.server -value secureconnect2.actifio.com
sleep 5

echo "${green}${bold}Starting SecureConnect..... ${reset}"
udstask setremotesupport -secureconnect on
sleep 8

echo "${green}${bold}Displaying tun output. Ensure that VPN IP is of the order 10.29.128.X ${reset}"
ifconfig tun0

#Grab VPN IP address
VPN_IP=$(ifconfig tun0 | egrep -o 'addr:([[:digit:]]{1,3}\.){3}[[:digit:]]{1,3}' | egrep -o '[[:digit:]].*')
echo "${green}${bold}"
echo "VPN IP address = ${magenta}${VPN_IP}"
echo -n "${green}${bold}"
echo "Test VPN connectivity: ${cyan}ssh ${VPN_IP} ${green}${bold} from local machine."
echo -n "${green}${bold}"
echo "If successful, VPN2 upgrade completed."

echo "One more thing to test is Actifio call home service."
echo "Testing OpenSSL Call Home Port 443....."
echo -n "${reset}"
openssl s_client -connect callhome.actifio.com:443 2>&1| grep -q "Verify return code: 0 (ok)"
if [ ! $? -eq 0 ]
then
    echo "${red}Could ot communicate with Actifio call home service!"
    echo "Please confirm with customer that port 443 is open on firewall"
    exit
fi
echo "${green}${bold}Contact with Actifio call home service successfully established."
echo "${reset}"